README.md

📈 BTC Forecast Project

A deep learning project that predicts the future price of Bitcoin (BTC/USDT) using historical price data and an LSTM neural network. This model forecasts daily prices until the end of the year following the latest available data.


🚀 Features
- Data Preprocessing: Cleans and formats CSV data for LSTM input.
- LSTM Model: Utilizes a multi-layer Long Short-Term Memory network for time-series forecasting.
- Custom Prediction Horizon: Extends predictions up to the last day of the following year.
- Visualization: Plots both historical and forecasted BTC prices.


📂 Dataset
The script expects a CSV file (`BTCUSDT.csv`) with the following columns:
- `Date` (YYYY-MM-DD)
- `Close` (BTC price in USDT)


🔧 Installation
```bash
pip install pandas matplotlib numpy scikit-learn tensorflow
```



▶️ Usage
1. Place your `BTCUSDT.csv` file in the project directory.
2. Run the script:
```bash
python btc_forecast.py
```
3. The forecast plot will be displayed, showing historical data and future predictions.


📊 Example Output
The output graph includes:
- Blue Line: Historical BTC price
- Orange Line: Predicted BTC price until the end of next year


⚠️ Disclaimer
This project is for 'educational purposes' only. Predictions are based on historical data and a machine learning model, which can be inaccurate. Do **not** use this as financial advice. Always do your own research before investing.

🧠 Model Architecture
- Input Layer: Sequence of past 60 closing prices
- Two LSTM Layers: 100 units each with dropout regularization
- Dense Layers: For final price prediction
- Loss Function: Mean Squared Error (MSE)
- Optimizer: Adam


📌 Future Improvements
- Include more features (volume, technical indicators)
- Hyperparameter tuning for better accuracy
- Experiment with different sequence lengths
- Add confidence intervals for predictions
